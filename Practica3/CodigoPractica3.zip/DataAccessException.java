

/**
 * Excepcion utilizada para indicar errores en el acceso a BBDD
 */
@SuppressWarnings("serial")
public class DataAccessException extends Exception {

}
